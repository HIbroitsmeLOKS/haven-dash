extends Node2D
## HAVEN Dash — Upgraded
## Self-contained rhythm platformer for Godot 4.
## Graphics, levels, music and SFX generated in code.
## New: custom face icon (camera / file), custom jump sound (mic record),
## richer backgrounds, more spike variety (incl. ceiling), polished UI.

const SAVE_PATH: String = "user://haven_dash.cfg"
const ICON_PATH: String = "user://player_icon.png"
const JUMP_SFX_PATH: String = "user://custom_jump.wav"
const RATE: float = 22050.0

const T: float = 48.0
const W: float = 1280.0
const H: float = 720.0
const GROUND_Y: float = 600.0
const SHIP_TOP: float = 168.0
const SPEED: float = 500.0
const GRAVITY: float = 3400.0
const JUMP_V: float = 900.0
const PAD_V: float = 1100.0
const PSIZE: float = 40.0
const PLAYER_SX: float = 300.0
const SHIP_UP: float = -2700.0
const SHIP_DOWN: float = 2300.0
const SHIP_MAXV: float = 470.0
const STEP: float = 1.0 / 240.0
const TOL: float = 14.0

enum State { NAME_ENTRY, MENU, PLAYING, DEAD, COMPLETE, CUSTOMIZE, CREDITS }
enum Mode { CUBE, SHIP }
enum CustomizeTab { FACE, SOUND }
enum PowerType { SPEED, SLOW, SHIELD }
enum IconType { CUBE, TRIANGLE, CIRCLE, DIAMOND, BALL, UFO }

const LEVELS: Array = [
	{"name": "Neon Start", "tag": "EASY", "hue": 0.58, "seed": 11, "length": 280, "gap_min": 10, "gap_max": 14, "ship": false, "pits": false, "bpm": 128.0, "root": 110.0, "hard": 0},
	{"name": "Pulse Drive", "tag": "NORMAL", "hue": 0.83, "seed": 27, "length": 380, "gap_min": 9, "gap_max": 12, "ship": true, "pits": true, "bpm": 140.0, "root": 98.0, "hard": 1},
	{"name": "Haven Rush", "tag": "HARD", "hue": 0.02, "seed": 93, "length": 460, "gap_min": 8, "gap_max": 11, "ship": true, "pits": true, "bpm": 152.0, "root": 123.47, "hard": 2},
]


class Particle:
	var pos: Vector2 = Vector2.ZERO
	var vel: Vector2 = Vector2.ZERO
	var life: float = 0.0
	var max_life: float = 1.0
	var color: Color = Color.WHITE
	var size: float = 4.0


# --- level data -------------------------------------------------------------
var blocks: Array[Rect2] = []
var spikes: Array[Rect2] = []
var ceiling_spikes: Array[Rect2] = []
var pads: Array[Rect2] = []
var pits: Array[Vector2] = []
var portal_x: Array[float] = []
var portal_mode: Array[int] = []
var end_x: float = 0.0
var coins: Array[Vector2] = []          # world positions of coins
var coin_got: Array[bool] = []
var powerups: Array = []                # {pos: Vector2, type: int, taken: bool}
var checkpoints: Array[float] = []      # x positions
var boss_x: float = -1.0
var boss_alive: bool = false
var boss_hp: float = 0.0
var boss_phase: float = 0.0

# --- game state -------------------------------------------------------------
var state: int = State.MENU
var mode: int = Mode.CUBE
var level_idx: int = 0
var best: Array[int] = [0, 0, 0]
var best_coins: Array[int] = [0, 0, 0]
var attempt: int = 1
var px: float = 0.0
var py: float = GROUND_Y - PSIZE
var vy: float = 0.0
var rot: float = 0.0
var on_ground: bool = true
var holding: bool = false
var jump_buffer: float = 0.0
var pad_cd: float = 0.0
var next_portal: int = 0
var cam_x: float = -PLAYER_SX
var menu_cam: float = 0.0
var acc: float = 0.0
var dead_timer: float = 0.0
var complete_timer: float = 0.0
var shake: float = 0.0
var shake_off: Vector2 = Vector2.ZERO
var flash: float = 0.0
var invincible: bool = false
var muted: bool = false
var trail_t: float = 0.0
var hue_base: float = 0.58
var particles: Array[Particle] = []
var bg_bars: Array[Vector2] = []
var bg_total: float = 1.0
var stars: Array[Vector2] = []
var title_pulse: float = 0.0
var credits_scroll: float = 0.0
var credits_from_complete: bool = false
var player_name: String = ""
var name_input: String = ""
var name_cursor_blink: float = 0.0
var pending_level: int = -1
var countdown: float = 0.0
var freeze_input: bool = false

# checkpoints / coins / powerups runtime
var coins_collected: int = 0
var coins_total: int = 0
var checkpoint_idx: int = -1
var respawn_x: float = 0.0
var respawn_y: float = 0.0
var speed_timer: float = 0.0
var slow_timer: float = 0.0
var shield_timer: float = 0.0
var base_speed: float = SPEED
var death_msg: String = ""
var icon_type: int = IconType.CUBE
var unlocked_icons: Array[bool] = [true, false, false, false, false, false]

const DEATH_MSGS: Array[String] = [
	"{name} wasted. Skill issue.",
	"Even the spikes are disappointed in {name}.",
	"That was free. {name} paid anyway.",
	"{name}'s brain offline. Try again.",
	"{name} jumped like they meant to die.",
	"Checkpoint right there. {name} missed it.",
	"The floor was lava. {name} knew.",
	"Respawning {name}'s dignity...",
	"Pro tip for {name}: don't touch the pointy bits.",
	"That spike had a family. {name} didn't care.",
	"Geometry Dash called. It wants {name}'s skill back.",
	"{name} vs gravity: gravity wins again.",
	"Hold jump, {name}. Or don't. Clearly.",
	"The ship section wasn't hard. {name} was.",
	"Touch grass? {name} should touch the ground first.",
	"{name} died to a triangle. Respectfully.",
	"{name}'s face icon looked sad watching that.",
	"One more try, {name}. Or twelve. We both know.",
	"Boss is laughing at {name}. So are we.",
	"{name} almost had it. Almost.",
]

# --- customization ----------------------------------------------------------
var customize_tab: int = CustomizeTab.FACE
var player_tex: ImageTexture = null
var has_custom_icon: bool = false
var camera_feed: CameraFeed = null
var camera_tex: CameraTexture = null
var camera_active: bool = false
var camera_preview: ImageTexture = null
var mic_recording: bool = false
var record_effect: AudioEffectRecord = null
var record_bus_idx: int = -1
var custom_jump: AudioStreamWAV = null
var has_custom_jump: bool = false
var record_timer: float = 0.0
var status_msg: String = ""
var status_timer: float = 0.0

# --- audio ------------------------------------------------------------------
var music_cache: Dictionary = {}
var music_player: AudioStreamPlayer
var sfx_players: Array[AudioStreamPlayer] = []
var sfx_idx: int = 0
var sfx_jump: AudioStreamWAV
var sfx_death: AudioStreamWAV
var sfx_pad: AudioStreamWAV
var sfx_portal: AudioStreamWAV
var sfx_win: AudioStreamWAV


func _ready() -> void:
	randomize()
	_load_save()
	_load_custom_assets()
	_make_bg()
	_setup_audio()
	_setup_mic()
	hue_base = float(LEVELS[level_idx]["hue"])
	set_process(true)
	# Try to enable camera monitoring early
	CameraServer.monitoring_feeds = true


func _exit_tree() -> void:
	_stop_camera()


# ============================================================================
# SAVE / CUSTOM ASSETS
# ============================================================================
func _load_save() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) == OK:
		for i in range(LEVELS.size()):
			best[i] = int(cfg.get_value("best", str(i), 0))
			best_coins[i] = int(cfg.get_value("coins", str(i), 0))
		icon_type = int(cfg.get_value("icon", "type", IconType.CUBE))
		for i in range(unlocked_icons.size()):
			unlocked_icons[i] = bool(cfg.get_value("icon", "u" + str(i), i == 0))
		player_name = str(cfg.get_value("player", "name", ""))
		if player_name != "":
			name_input = player_name


func _save() -> void:
	var cfg := ConfigFile.new()
	for i in range(LEVELS.size()):
		cfg.set_value("best", str(i), best[i])
		cfg.set_value("coins", str(i), best_coins[i])
	cfg.set_value("icon", "type", icon_type)
	for i in range(unlocked_icons.size()):
		cfg.set_value("icon", "u" + str(i), unlocked_icons[i])
	cfg.set_value("player", "name", player_name)
	cfg.save(SAVE_PATH)


func _load_custom_assets() -> void:
	# Face icon
	if FileAccess.file_exists(ICON_PATH):
		var img := Image.new()
		if img.load(ICON_PATH) == OK:
			img.resize(64, 64, Image.INTERPOLATE_LANCZOS)
			player_tex = ImageTexture.create_from_image(img)
			has_custom_icon = true
	# Custom jump SFX
	if FileAccess.file_exists(JUMP_SFX_PATH):
		var f := FileAccess.open(JUMP_SFX_PATH, FileAccess.READ)
		if f:
			var bytes: PackedByteArray = f.get_buffer(f.get_length())
			f.close()
			var w := AudioStreamWAV.new()
			w.format = AudioStreamWAV.FORMAT_16_BITS
			w.mix_rate = int(RATE)
			w.stereo = false
			w.data = bytes
			custom_jump = w
			has_custom_jump = true
			sfx_jump = custom_jump


func _save_icon(img: Image) -> void:
	img.save_png(ICON_PATH)
	img.resize(64, 64, Image.INTERPOLATE_LANCZOS)
	player_tex = ImageTexture.create_from_image(img)
	has_custom_icon = true
	_set_status("Face icon saved!")


func _save_jump_sfx(stream: AudioStreamWAV) -> void:
	custom_jump = stream
	sfx_jump = stream
	has_custom_jump = true
	var f := FileAccess.open(JUMP_SFX_PATH, FileAccess.WRITE)
	if f:
		f.store_buffer(stream.data)
		f.close()
	_set_status("Jump sound saved!")


func _set_status(msg: String) -> void:
	status_msg = msg
	status_timer = 2.5


# ============================================================================
# LEVEL GENERATION (richer patterns + ceiling spikes)
# ============================================================================
func _add_block(c: float, row: float, w: float, h: float) -> void:
	blocks.append(Rect2(c * T, GROUND_Y - (row + h) * T, w * T, h * T))


func _add_spike(c: float, row: float) -> void:
	spikes.append(Rect2(c * T, GROUND_Y - (row + 1.0) * T, T, T))


func _add_ceiling_spike(c: float, from_top: float = 0.0) -> void:
	# from_top in tiles down from ship ceiling / screen top area
	ceiling_spikes.append(Rect2(c * T, SHIP_TOP + from_top * T, T, T))


func _add_pad(c: float) -> void:
	pads.append(Rect2(c * T, GROUND_Y - 14.0, T, 14.0))


func _safe_checkpoint_x(x: float) -> float:
	# Push checkpoint forward until clear of spikes, pits, pads (up to ~4 tiles)
	var tries: int = 0
	while tries < 12:
		var clear := true
		for s: Rect2 in spikes:
			if absf(s.position.x + T * 0.5 - x) < T * 2.5:
				clear = false
				break
		if clear:
			for s: Rect2 in ceiling_spikes:
				if absf(s.position.x + T * 0.5 - x) < T * 2.5:
					clear = false
					break
		if clear:
			for p: Vector2 in pits:
				if x >= p.x - T and x <= p.y + T:
					clear = false
					break
		if clear:
			for pad: Rect2 in pads:
				if absf(pad.position.x + T * 0.5 - x) < T * 2.0:
					clear = false
					break
		if clear:
			return x
		x += T
		tries += 1
	return x


func _build_level(idx: int) -> void:
	blocks.clear()
	spikes.clear()
	ceiling_spikes.clear()
	pads.clear()
	pits.clear()
	portal_x.clear()
	portal_mode.clear()
	coins.clear()
	coin_got.clear()
	powerups.clear()
	checkpoints.clear()
	boss_x = -1.0
	boss_alive = false
	boss_hp = 0.0
	var cfg: Dictionary = LEVELS[idx]
	var rng := RandomNumberGenerator.new()
	rng.seed = int(cfg["seed"])
	var length: int = int(cfg["length"])
	var gap_min: int = int(cfg["gap_min"])
	var gap_max: int = int(cfg["gap_max"])
	var hard: int = int(cfg["hard"])
	var allow_ship: bool = bool(cfg["ship"])
	var allow_pits: bool = bool(cfg["pits"])
	var col: int = 16
	var since_ship: int = 0
	while col < length - 30:
		col += rng.randi_range(gap_min, gap_max)
		if allow_ship and since_ship >= 5 and rng.randf() < 0.28:
			col = _gen_ship(rng, col, hard)
			since_ship = 0
		else:
			since_ship += 1
			col = _gen_cube(rng, col, hard, allow_pits)
	end_x = float(maxi(length, col + 12)) * T
	# Checkpoints every ~22% — snap away from spikes / pits / pads
	for p in [0.22, 0.44, 0.66, 0.85]:
		var cx: float = end_x * p
		cx = _safe_checkpoint_x(cx)
		checkpoints.append(cx)
	# Coins scattered along the run
	var coin_n: int = 8 + hard * 4
	for i in range(coin_n):
		var cx: float = rng.randf_range(end_x * 0.08, end_x * 0.95)
		var cy: float = GROUND_Y - PSIZE * 0.5 - rng.randf_range(20.0, 140.0)
		coins.append(Vector2(cx, cy))
		coin_got.append(false)
	coins_total = coins.size()
	# Power-ups
	var pu_n: int = 3 + hard
	for i in range(pu_n):
		var pt: int = [PowerType.SPEED, PowerType.SLOW, PowerType.SHIELD][i % 3]
		var pp := Vector2(rng.randf_range(end_x * 0.12, end_x * 0.88), GROUND_Y - 70.0 - rng.randf_range(0.0, 80.0))
		powerups.append({"pos": pp, "type": pt, "taken": false})
	# Boss on Hard only — near the end
	if hard >= 2:
		boss_x = end_x * 0.78
		boss_alive = true
		boss_hp = 3.0
		boss_phase = 0.0


func _gen_cube(rng: RandomNumberGenerator, col: int, hard: int, allow_pits: bool) -> int:
	# Easier pools: more safe platforms, fewer dense clusters
	var pools: Array = [
		[0, 0, 1, 1, 2, 2, 2, 3],             # easy — lots of breathing room
		[0, 0, 1, 1, 2, 2, 3, 3, 5, 6],       # normal
		[0, 1, 2, 2, 3, 3, 4, 5, 6, 7],       # hard (still fair)
	]
	var pool: Array = pools[hard]
	var kind: int = int(pool[rng.randi_range(0, pool.size() - 1)])
	if kind == 4 and not allow_pits:
		kind = 0
	match kind:
		0: # small spike cluster
			var maxn: int = 1 if hard == 0 else (2 if hard == 1 else 3)
			var n: int = rng.randi_range(1, maxn)
			for i in range(n):
				_add_spike(col + i, 0)
			return col + n + 1  # extra gap after spikes
		1: # block + single spike
			_add_block(col, 0, 1, 1)
			_add_spike(col + 1, 0)
			return col + 3
		2: # comfortable platform + trailing spike
			var w: int = rng.randi_range(5, 8)
			_add_block(col, 0, w, 1)
			_add_spike(col + w + 1, 0)
			return col + w + 3
		3: # long safe block, light top threat
			_add_block(col, 0, 12, 1)
			if hard >= 1 and rng.randf() < 0.55:
				_add_spike(col + 7, 1)
			return col + 12
		4: # pit (narrower + rarer)
			var pw: int = rng.randi_range(2, 3)
			pits.append(Vector2(float(col) * T, float(col + pw) * T))
			return col + pw + 1
		5: # pad + short spike run
			_add_pad(col)
			for i in range(2 if hard < 2 else 3):
				_add_spike(col + 2 + i, 0)
			return col + 5
		6: # two spikes then platform
			_add_spike(col, 0)
			_add_spike(col + 1, 0)
			_add_block(col + 3, 0, 3, 1)
			return col + 7
		7: # mild elevated threat
			_add_block(col, 0, 4, 1)
			_add_spike(col + 2, 1)
			if hard >= 2 and rng.randf() < 0.4:
				_add_ceiling_spike(col + 5, 0.0)
			return col + 7
		8: # denser (hard only, still spaced)
			for i in range(3):
				_add_spike(col + i, 0)
			_add_block(col + 4, 0, 3, 1)
			_add_spike(col + 8, 0)
			return col + 10
	return col + 1


func _gen_ship(rng: RandomNumberGenerator, col: int, hard: int) -> int:
	portal_x.append(float(col) * T)
	portal_mode.append(Mode.SHIP)
	var n: int = rng.randi_range(4, 5 + hard)
	var spacing: int = 7 if hard < 2 else 6
	var span: int = 9 + n * spacing + 4
	blocks.append(Rect2(float(col) * T, -400.0, float(span) * T, SHIP_TOP + 400.0))
	var c: int = col + 9
	for i in range(n):
		var h: int = rng.randi_range(1, 2 if hard < 2 else 3)
		if rng.randf() < 0.55:
			_add_block(c, 0, 2, h)
		else:
			blocks.append(Rect2(float(c) * T, SHIP_TOP, 2.0 * T, float(h) * T))
		# lighter ceiling threats
		if hard >= 1 and rng.randf() < 0.22:
			_add_ceiling_spike(c + 1, 0.0)
		if hard >= 2 and rng.randf() < 0.18:
			_add_ceiling_spike(c, 1.0)
		c += spacing
	var end_col: int = col + span
	portal_x.append(float(end_col) * T)
	portal_mode.append(Mode.CUBE)
	return end_col + 4


# ============================================================================
# FLOW
# ============================================================================
func _reset_run() -> void:
	var from_cp := checkpoint_idx >= 0 and checkpoint_idx < checkpoints.size()
	if from_cp:
		px = checkpoints[checkpoint_idx] - 40.0
		py = GROUND_Y - PSIZE
	else:
		px = 0.0
		py = GROUND_Y - PSIZE
	vy = 0.0
	rot = 0.0
	on_ground = true
	mode = Mode.CUBE
	next_portal = 0
	while next_portal < portal_x.size() and portal_x[next_portal] < px:
		next_portal += 1
		if next_portal > 0:
			mode = portal_mode[next_portal - 1]
	jump_buffer = 0.0
	pad_cd = 0.0
	acc = 0.0
	trail_t = 0.0
	speed_timer = 0.0
	slow_timer = 0.0
	shield_timer = 0.0
	holding = false
	particles.clear()
	cam_x = px - PLAYER_SX
	# 3s freeze after checkpoint respawn so you don't instantly jump/die
	if from_cp:
		countdown = 3.0
		freeze_input = true
	else:
		countdown = 0.0
		freeze_input = false


func _start_level(idx: int) -> void:
	level_idx = idx
	hue_base = float(LEVELS[idx]["hue"])
	_build_level(idx)
	attempt = 1
	checkpoint_idx = -1
	respawn_x = 0.0
	respawn_y = GROUND_Y - PSIZE
	coins_collected = 0
	for i in range(coin_got.size()):
		coin_got[i] = false
	for p in powerups:
		p["taken"] = false
	if int(LEVELS[idx]["hard"]) >= 2:
		boss_alive = true
		boss_hp = 3.0
		boss_phase = 0.0
	_reset_run()
	# brief countdown even at start of level
	countdown = 3.0
	freeze_input = true
	holding = false
	jump_buffer = 0.0
	state = State.PLAYING
	_play_music()


func _request_level(idx: int) -> void:
	# Ask for name every time a level is chosen, then start
	pending_level = idx
	name_input = player_name
	state = State.NAME_ENTRY
	music_player.stop()


func _restart() -> void:
	attempt += 1
	_reset_run()
	state = State.PLAYING
	_play_music()


func _to_menu() -> void:
	state = State.MENU
	music_player.stop()
	particles.clear()
	shake = 0.0
	_stop_camera()
	mic_recording = false
	credits_from_complete = false
	credits_scroll = 0.0


func _to_customize() -> void:
	state = State.CUSTOMIZE
	customize_tab = CustomizeTab.FACE
	music_player.stop()
	_stop_camera()
	mic_recording = false
	status_msg = ""


func _to_credits(from_complete: bool = false) -> void:
	state = State.CREDITS
	credits_from_complete = from_complete
	credits_scroll = 0.0
	music_player.stop()
	_stop_camera()
	mic_recording = false
	particles.clear()


func _confirm_name() -> void:
	player_name = name_input.strip_edges()
	if player_name == "":
		player_name = "Player"
	if player_name.length() > 12:
		player_name = player_name.substr(0, 12)
	_save()
	if pending_level >= 0:
		var idx: int = pending_level
		pending_level = -1
		_start_level(idx)
	else:
		state = State.MENU
		_set_status("Welcome, " + player_name + "!")


func _die() -> void:
	if invincible or shield_timer > 0.0:
		if shield_timer > 0.0:
			shield_timer = 0.0
			_burst(Vector2(px + PSIZE * 0.5, py + PSIZE * 0.5), 16, Color(0.4, 0.8, 1.0), 280.0)
		return
	state = State.DEAD
	dead_timer = 0.0
	shake = 0.75
	flash = 0.85
	music_player.stop()
	_play_sfx(sfx_death)
	var n: String = player_name if player_name != "" else "Player"
	death_msg = DEATH_MSGS[randi() % DEATH_MSGS.size()].replace("{name}", n)
	var center := Vector2(px + PSIZE * 0.5, py + PSIZE * 0.5)
	_burst(center, 40, Color(1.0, 0.3, 0.3), 600.0)
	_burst(center, 25, Color(1.0, 0.7, 0.2), 400.0)


func _complete() -> void:
	state = State.COMPLETE
	complete_timer = 0.0
	music_player.stop()
	_play_sfx(sfx_win)
	var pct: int = int(_pct())
	if pct > best[level_idx] and not invincible:
		best[level_idx] = pct
	if coins_collected > best_coins[level_idx]:
		best_coins[level_idx] = coins_collected
	# Unlock icons: finish any level -> triangle; 5+ coins -> circle; full coins -> diamond; hard finish -> ball+ufo
	if not unlocked_icons[IconType.TRIANGLE]:
		unlocked_icons[IconType.TRIANGLE] = true
	if coins_collected >= 5:
		unlocked_icons[IconType.CIRCLE] = true
	if coins_collected >= coins_total and coins_total > 0:
		unlocked_icons[IconType.DIAMOND] = true
	if int(LEVELS[level_idx]["hard"]) >= 2:
		unlocked_icons[IconType.BALL] = true
		unlocked_icons[IconType.UFO] = true
	_save()
	var center := Vector2(px + PSIZE * 0.5, py + PSIZE * 0.5)
	_burst(center, 30, Color(0.4, 1.0, 0.6), 500.0)
	_burst(center, 30, Color(1.0, 0.85, 0.2), 500.0)
	_burst(center, 30, Color(1.0, 0.4, 0.8), 500.0)


func _pct() -> float:
	if end_x <= 0.0:
		return 0.0
	return clampf(px / end_x * 100.0, 0.0, 100.0)


func _hue_now() -> float:
	if state == State.MENU or state == State.CUSTOMIZE:
		return hue_base
	return fposmod(hue_base + _pct() * 0.0012, 1.0)


# ============================================================================
# INPUT
# ============================================================================
func _press() -> void:
	if freeze_input or countdown > 0.0:
		holding = false
		jump_buffer = 0.0
		return
	holding = true
	jump_buffer = 0.12
	if state == State.MENU:
		_request_level(level_idx)
	elif state == State.COMPLETE and complete_timer > 0.8:
		_to_credits(true)
	elif state == State.DEAD and dead_timer > 0.25:
		_restart()
	elif state == State.CREDITS:
		if credits_from_complete and credits_scroll > 160.0:
			_to_menu()
		elif not credits_from_complete:
			_to_menu()
	elif state == State.CUSTOMIZE:
		if customize_tab == CustomizeTab.FACE and camera_active:
			_capture_face()
		elif customize_tab == CustomizeTab.SOUND and not mic_recording:
			_start_mic_record()
		elif customize_tab == CustomizeTab.SOUND and mic_recording:
			_stop_mic_record()


func _release() -> void:
	holding = false


func _menu_move(d: int) -> void:
	if state != State.MENU:
		return
	level_idx = posmod(level_idx + d, LEVELS.size())
	hue_base = float(LEVELS[level_idx]["hue"])


func _card_rect(i: int) -> Rect2:
	return Rect2(100.0 + float(i) * 370.0, 230.0, 340.0, 250.0)


func _customize_btn_rect() -> Rect2:
	return Rect2(W * 0.5 - 290.0, 560.0, 260.0, 48.0)


func _credits_btn_rect() -> Rect2:
	return Rect2(W * 0.5 + 30.0, 560.0, 260.0, 48.0)


func _pointer_down(pos: Vector2) -> void:
	if state == State.MENU:
		for i in range(LEVELS.size()):
			if _card_rect(i).has_point(pos):
				_request_level(i)
				return
		if _customize_btn_rect().has_point(pos):
			_to_customize()
			return
		if _credits_btn_rect().has_point(pos):
			_to_credits(false)
			return
		return
	if state == State.CUSTOMIZE:
		# tab buttons
		var face_r := Rect2(W * 0.5 - 220.0, 120.0, 200.0, 44.0)
		var sound_r := Rect2(W * 0.5 + 20.0, 120.0, 200.0, 44.0)
		if face_r.has_point(pos):
			customize_tab = CustomizeTab.FACE
			_stop_camera()
			mic_recording = false
			return
		if sound_r.has_point(pos):
			customize_tab = CustomizeTab.SOUND
			_stop_camera()
			return
		# action buttons depend on tab
		if customize_tab == CustomizeTab.FACE:
			var cam_r := Rect2(W * 0.5 - 300.0, 520.0, 190.0, 50.0)
			var file_r := Rect2(W * 0.5 - 90.0, 520.0, 180.0, 50.0)
			var clear_r := Rect2(W * 0.5 + 110.0, 520.0, 170.0, 50.0)
			var prev_r := Rect2(W * 0.5 - 110.0, 215.0, 220.0, 220.0)
			if cam_r.has_point(pos):
				_toggle_camera()
				return
			if file_r.has_point(pos):
				_pick_icon_file()
				return
			if clear_r.has_point(pos):
				player_tex = null
				has_custom_icon = false
				if FileAccess.file_exists(ICON_PATH):
					DirAccess.remove_absolute(ICON_PATH)
				_set_status("Face icon cleared")
				return
			# Click preview while camera is live = capture
			if camera_active and prev_r.has_point(pos):
				_capture_face()
				return
		else:
			var rec_r := Rect2(W * 0.5 - 200.0, 480.0, 180.0, 48.0)
			var clear_r := Rect2(W * 0.5 + 20.0, 480.0, 180.0, 48.0)
			if rec_r.has_point(pos):
				if mic_recording:
					_stop_mic_record()
				else:
					_start_mic_record()
				return
			if clear_r.has_point(pos):
				custom_jump = null
				has_custom_jump = false
				sfx_jump = _wav(_tone(0.12, 420.0, 880.0, 0.25, 1), false, RATE)
				if FileAccess.file_exists(JUMP_SFX_PATH):
					DirAccess.remove_absolute(JUMP_SFX_PATH)
				_set_status("Jump sound reset to default")
				return
		return
	_press()


func _input(event: InputEvent) -> void:
	if state == State.NAME_ENTRY:
		if event is InputEventKey and event.pressed and not event.echo:
			var k: InputEventKey = event as InputEventKey
			if k.keycode == KEY_ENTER or k.keycode == KEY_KP_ENTER:
				_confirm_name()
			elif k.keycode == KEY_BACKSPACE:
				if name_input.length() > 0:
					name_input = name_input.substr(0, name_input.length() - 1)
			elif k.keycode == KEY_ESCAPE:
				pending_level = -1
				state = State.MENU
			else:
				var ch: String = String.chr(k.unicode) if k.unicode > 0 else ""
				if ch.length() == 1 and name_input.length() < 12:
					var c: String = ch
					# allow letters, numbers, space, underscore
					if (c >= "a" and c <= "z") or (c >= "A" and c <= "Z") or (c >= "0" and c <= "9") or c == " " or c == "_":
						name_input += c
		return
	if event is InputEventKey:
		var k: InputEventKey = event as InputEventKey
		if k.echo:
			return
		var code: int = k.keycode
		if code == KEY_SPACE or code == KEY_UP or code == KEY_W or code == KEY_ENTER or code == KEY_KP_ENTER:
			if k.pressed:
				_press()
			else:
				_release()
		elif k.pressed:
			if code == KEY_LEFT or code == KEY_A:
				if state == State.MENU:
					_menu_move(-1)
				elif state == State.CUSTOMIZE:
					customize_tab = CustomizeTab.FACE
					_stop_camera()
			elif code == KEY_RIGHT or code == KEY_D:
				if state == State.MENU:
					_menu_move(1)
				elif state == State.CUSTOMIZE:
					customize_tab = CustomizeTab.SOUND
					_stop_camera()
			elif code == KEY_ESCAPE:
				if state == State.CUSTOMIZE or state == State.CREDITS:
					_to_menu()
				elif state != State.MENU:
					_to_menu()
			elif code == KEY_I:
				invincible = not invincible
			elif code == KEY_M:
				muted = not muted
				music_player.volume_db = -80.0 if muted else -9.0
			elif code == KEY_C and state == State.MENU:
				_to_customize()
			elif code == KEY_O and state == State.MENU:
				# cycle unlocked icons
				var start: int = icon_type
				for _k in range(unlocked_icons.size()):
					icon_type = (icon_type + 1) % unlocked_icons.size()
					if unlocked_icons[icon_type]:
						_save()
						var names = ["Cube", "Triangle", "Circle", "Diamond", "Ball", "UFO"]
						_set_status("Icon: " + names[icon_type])
						break
				if icon_type == start and not unlocked_icons[icon_type]:
					icon_type = IconType.CUBE
	elif event is InputEventMouseButton:
		var mb: InputEventMouseButton = event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed:
				_pointer_down(mb.position)
			else:
				_release()


# ============================================================================
# CAMERA (face capture)
# ============================================================================
func _toggle_camera() -> void:
	if camera_active:
		_stop_camera()
		_set_status("Camera closed")
		return
	CameraServer.monitoring_feeds = true
	var feeds: Array = CameraServer.feeds()
	if feeds.is_empty():
		_set_status("No camera found. Use Load Image instead.")
		return
	# Prefer front-facing if the feed name hints at it
	camera_feed = feeds[0]
	for f in feeds:
		var n: String = str(f.get_name()).to_lower()
		if "front" in n or "face" in n or "user" in n:
			camera_feed = f
			break
	if camera_feed == null:
		_set_status("Camera feed unavailable")
		return
	var formats: Array = camera_feed.get_formats()
	var chosen := -1
	var best_area := 0
	for i in range(formats.size()):
		var f: Dictionary = formats[i]
		var w: int = int(f.get("width", 0))
		var h: int = int(f.get("height", 0))
		var area: int = w * h
		if w >= 320 and w <= 1280 and h >= 240 and area > best_area:
			best_area = area
			chosen = i
	if chosen >= 0:
		camera_feed.set_format(chosen, {})
	camera_feed.set_active(true)
	camera_tex = CameraTexture.new()
	camera_tex.camera_feed_id = camera_feed.get_id()
	camera_active = true
	_set_status("Camera live — centre your face in the square, then SPACE / click to snap")


func _stop_camera() -> void:
	if camera_feed:
		camera_feed.set_active(false)
	camera_feed = null
	camera_tex = null
	camera_active = false
	camera_preview = null


func _capture_face() -> void:
	if not camera_active or camera_tex == null:
		return
	var img: Image = null
	if camera_tex.get_image() != null:
		img = camera_tex.get_image()
	if img == null or img.is_empty():
		_set_status("Could not grab frame — try again or use Load Image")
		return
	# Centre-crop to square (slightly tighter for faces)
	var w: int = img.get_width()
	var h: int = img.get_height()
	var sz: int = mini(w, h)
	# Prefer a bit more of the upper part (faces sit higher)
	var x0: int = (w - sz) / 2
	var y0: int = maxi(0, (h - sz) / 2 - int(sz * 0.08))
	if y0 + sz > h:
		y0 = h - sz
	var cropped := img.get_region(Rect2i(x0, y0, sz, sz))
	# Mild sharpen / contrast-ish by simple resize up then down is overkill;
	# just make a nice 128px icon
	cropped.resize(128, 128, Image.INTERPOLATE_LANCZOS)
	_save_icon(cropped)
	_stop_camera()
	flash = 0.55  # nice shutter flash
	_set_status("Face captured! Looking good.")


func _pick_icon_file() -> void:
	# Use a simple native file dialog if available
	var dlg := FileDialog.new()
	dlg.file_mode = FileDialog.FILE_MODE_OPEN_FILE
	dlg.access = FileDialog.ACCESS_FILESYSTEM
	dlg.filters = PackedStringArray(["*.png ; PNG Images", "*.jpg ; JPEG Images", "*.jpeg ; JPEG Images", "*.webp ; WebP Images"])
	dlg.title = "Choose Face Image"
	dlg.size = Vector2i(800, 500)
	add_child(dlg)
	dlg.file_selected.connect(func(path: String):
		var img := Image.new()
		if img.load(path) == OK:
			var sz: int = mini(img.get_width(), img.get_height())
			var x0: int = (img.get_width() - sz) / 2
			var y0: int = (img.get_height() - sz) / 2
			var cropped := img.get_region(Rect2i(x0, y0, sz, sz))
			cropped.resize(128, 128, Image.INTERPOLATE_LANCZOS)
			_save_icon(cropped)
		else:
			_set_status("Failed to load image")
		dlg.queue_free()
	)
	dlg.canceled.connect(func(): dlg.queue_free())
	dlg.popup_centered()


# ============================================================================
# MICROPHONE (custom jump sound)
# ============================================================================
func _setup_mic() -> void:
	# Ensure a Record bus exists with AudioEffectRecord
	record_bus_idx = AudioServer.get_bus_index("Record")
	if record_bus_idx == -1:
		AudioServer.add_bus()
		record_bus_idx = AudioServer.bus_count - 1
		AudioServer.set_bus_name(record_bus_idx, "Record")
		AudioServer.set_bus_send(record_bus_idx, "Master")
	# Clear existing effects and add record
	while AudioServer.get_bus_effect_count(record_bus_idx) > 0:
		AudioServer.remove_bus_effect(record_bus_idx, 0)
	record_effect = AudioEffectRecord.new()
	AudioServer.add_bus_effect(record_bus_idx, record_effect)
	# Mute the record bus so we don't hear the mic live
	AudioServer.set_bus_mute(record_bus_idx, true)


func _start_mic_record() -> void:
	if record_effect == null:
		_set_status("Mic not available (enable audio input in project)")
		return
	# Need an AudioStreamPlayer playing the mic into the Record bus
	var mic_player := get_node_or_null("MicPlayer") as AudioStreamPlayer
	if mic_player == null:
		mic_player = AudioStreamPlayer.new()
		mic_player.name = "MicPlayer"
		mic_player.stream = AudioStreamMicrophone.new()
		mic_player.bus = "Record"
		add_child(mic_player)
	mic_player.play()
	record_effect.set_recording_active(true)
	mic_recording = true
	record_timer = 0.0
	_set_status("Recording... press SPACE or button again to stop (max 1.5s)")


func _stop_mic_record() -> void:
	if not mic_recording or record_effect == null:
		return
	record_effect.set_recording_active(false)
	mic_recording = false
	var rec: AudioStreamWAV = record_effect.get_recording()
	var mic_player := get_node_or_null("MicPlayer") as AudioStreamPlayer
	if mic_player:
		mic_player.stop()
	if rec == null or rec.data.size() < 1000:
		_set_status("Recording too short or empty — try again")
		return
	# Trim / convert to our RATE mono 16-bit roughly
	# For simplicity keep as-is but ensure format matches
	rec.mix_rate = int(RATE) if rec.mix_rate == 0 else rec.mix_rate
	# Limit length ~1.2s
	var max_samples: int = int(rec.mix_rate * 1.2) * (2 if rec.stereo else 1) * 2 # rough bytes
	if rec.data.size() > max_samples:
		rec.data = rec.data.slice(0, max_samples)
	_save_jump_sfx(rec)
	_play_sfx(rec) # preview


# ============================================================================
# SIMULATION
# ============================================================================
func _has_ground(x0: float, x1: float) -> bool:
	for p: Vector2 in pits:
		if x0 >= p.x and x1 <= p.y:
			return false
	return true


func _sim(dt: float) -> void:
	# Frozen during countdown — no movement, no jump
	if freeze_input or countdown > 0.0:
		holding = false
		jump_buffer = 0.0
		vy = 0.0
		return
	var prev_y: float = py
	# power-up timers
	if speed_timer > 0.0:
		speed_timer -= dt
	if slow_timer > 0.0:
		slow_timer -= dt
	if shield_timer > 0.0:
		shield_timer -= dt
	var spd: float = SPEED
	if speed_timer > 0.0:
		spd *= 1.45
	if slow_timer > 0.0:
		spd *= 0.55
	px += spd * dt
	if pad_cd > 0.0:
		pad_cd -= dt
	if jump_buffer > 0.0:
		jump_buffer -= dt

	# portals
	while next_portal < portal_x.size() and px + PSIZE * 0.5 >= portal_x[next_portal]:
		var new_mode: int = portal_mode[next_portal]
		next_portal += 1
		if new_mode != mode:
			mode = new_mode
			rot = 0.0
			if mode == Mode.SHIP:
				vy = 0.0
				on_ground = false
			_burst(Vector2(px + PSIZE * 0.5, py + PSIZE * 0.5), 18, Color(1.0, 1.0, 1.0), 300.0)
			_play_sfx(sfx_portal)

	# movement
	if mode == Mode.CUBE:
		if on_ground and (holding or jump_buffer > 0.0):
			vy = -JUMP_V
			on_ground = false
			jump_buffer = 0.0
			_play_sfx(sfx_jump)
		vy = minf(vy + GRAVITY * dt, 1400.0)
	else:
		var ay: float = SHIP_UP if holding else SHIP_DOWN
		vy = clampf(vy + ay * dt, -SHIP_MAXV, SHIP_MAXV)
	py += vy * dt
	on_ground = false
	var vy_in: float = vy

	# ground
	if vy >= 0.0 and py + PSIZE >= GROUND_Y and prev_y + PSIZE <= GROUND_Y + TOL and _has_ground(px, px + PSIZE):
		py = GROUND_Y - PSIZE
		vy = 0.0
		on_ground = true

	# blocks
	var pr := Rect2(px, py, PSIZE, PSIZE)
	for b: Rect2 in blocks:
		if b.end.x < px - 2.0 or b.position.x > px + PSIZE + 2.0:
			continue
		if not pr.intersects(b):
			continue
		if vy_in >= 0.0 and prev_y + PSIZE <= b.position.y + TOL:
			py = b.position.y - PSIZE
			vy = 0.0
			on_ground = true
			pr.position.y = py
		elif vy_in < 0.0 and prev_y >= b.end.y - TOL:
			py = b.end.y
			vy = 0.0
			pr.position.y = py
		elif not invincible and shield_timer <= 0.0:
			_die()
			return

	# floor spikes
	if not invincible and shield_timer <= 0.0:
		var hit_r := Rect2(px + 5.0, py + 5.0, PSIZE - 10.0, PSIZE - 10.0)
		for s: Rect2 in spikes:
			if s.end.x < px - 2.0 or s.position.x > px + PSIZE + 2.0:
				continue
			var hb := Rect2(s.position.x + T * 0.3, s.position.y + T * 0.45, T * 0.4, T * 0.55)
			if hit_r.intersects(hb):
				_die()
				return
		# ceiling spikes
		for s: Rect2 in ceiling_spikes:
			if s.end.x < px - 2.0 or s.position.x > px + PSIZE + 2.0:
				continue
			var hb := Rect2(s.position.x + T * 0.25, s.position.y, T * 0.5, T * 0.55)
			if hit_r.intersects(hb):
				_die()
				return

	# pads
	if mode == Mode.CUBE and pad_cd <= 0.0:
		var pr2 := Rect2(px, py, PSIZE, PSIZE)
		for p: Rect2 in pads:
			if p.end.x < px - 2.0 or p.position.x > px + PSIZE + 2.0:
				continue
			if pr2.intersects(p):
				vy = -PAD_V
				on_ground = false
				pad_cd = 0.2
				_burst(Vector2(px + PSIZE * 0.5, py + PSIZE), 14, Color(1.0, 0.9, 0.2), 260.0)
				_play_sfx(sfx_pad)
				break

	# falling into a pit
	if py > H + 100.0:
		if invincible:
			py = 100.0
			vy = 0.0
		else:
			_die()
			return

	# visuals
	if mode == Mode.CUBE:
		if on_ground:
			rot = lerpf(rot, snappedf(rot, PI * 0.5), minf(1.0, 18.0 * dt))
		else:
			rot += 9.0 * dt * signf(vy) if absf(vy) > 50.0 else 0.0
	else:
		rot = lerpf(rot, clampf(vy * 0.0008, -0.5, 0.5), minf(1.0, 10.0 * dt))

	trail_t += dt
	if trail_t > 0.04:
		trail_t = 0.0
		if mode == Mode.CUBE and not on_ground:
			_spawn(Vector2(px + PSIZE * 0.5, py + PSIZE), Vector2(randf_range(-40.0, 40.0), 80.0), 0.35, Color(1.0, 0.85, 0.3), 5.0)
		elif mode == Mode.SHIP:
			_spawn(Vector2(px - 6.0, py + PSIZE * 0.6), Vector2(-220.0, randf_range(-50.0, 50.0)), 0.3, Color(1.0, 0.6, 0.2), 6.0)

	# coins
	var pr_c := Rect2(px, py, PSIZE, PSIZE)
	for i in range(coins.size()):
		if coin_got[i]:
			continue
		var cpos: Vector2 = coins[i]
		if absf(cpos.x - px) > 200.0:
			continue
		if pr_c.grow(8.0).has_point(cpos):
			coin_got[i] = true
			coins_collected += 1
			_burst(cpos, 10, Color(1.0, 0.85, 0.2), 220.0)
			_play_sfx(sfx_pad)

	# power-ups
	for p in powerups:
		if p["taken"]:
			continue
		var ppos: Vector2 = p["pos"]
		if absf(ppos.x - px) > 200.0:
			continue
		if pr_c.grow(12.0).has_point(ppos):
			p["taken"] = true
			match int(p["type"]):
				PowerType.SPEED:
					speed_timer = 3.5
					_set_status("SPEED BOOST!")
				PowerType.SLOW:
					slow_timer = 3.0
					_set_status("SLOW-MO!")
				PowerType.SHIELD:
					shield_timer = 4.0
					_set_status("SHIELD ON!")
			_burst(ppos, 14, Color(0.4, 0.9, 1.0), 260.0)
			_play_sfx(sfx_portal)

	# checkpoints
	for i in range(checkpoints.size()):
		if i <= checkpoint_idx:
			continue
		if px >= checkpoints[i]:
			checkpoint_idx = i
			respawn_x = checkpoints[i] - 20.0
			respawn_y = GROUND_Y - PSIZE
			_set_status("CHECKPOINT %d" % (i + 1))
			_burst(Vector2(checkpoints[i], GROUND_Y - 40.0), 12, Color(0.3, 1.0, 0.5), 200.0)

	# boss (Hard)
	if boss_alive and boss_x > 0.0:
		boss_phase += dt
		var bpos := Vector2(boss_x, GROUND_Y - 90.0 + sin(boss_phase * 2.2) * 50.0)
		# boss projectiles every so often
		if fmod(boss_phase, 1.1) < dt:
			_spawn(bpos, Vector2(-320.0 - randf() * 80.0, randf_range(-120.0, 80.0)), 1.2, Color(1.0, 0.2, 0.4), 10.0)
		# player near boss = damage boss by jumping on / passing (simple: touch reduces hp)
		if absf(px - boss_x) < 55.0 and absf(py - bpos.y) < 70.0:
			if vy > 100.0 or shield_timer > 0.0:
				boss_hp -= 1.0
				vy = -JUMP_V * 0.8
				_burst(bpos, 20, Color(1.0, 0.3, 0.5), 400.0)
				if boss_hp <= 0.0:
					boss_alive = false
					_set_status("BOSS DOWN!")
					_burst(bpos, 40, Color(1.0, 0.2, 0.3), 600.0)
			elif not invincible and shield_timer <= 0.0:
				_die()
				return
		# contact with boss projectiles (reuse red particles near player)
		for part in particles:
			if part.color.r > 0.9 and part.color.g < 0.35 and part.size >= 9.0:
				if Vector2(px + PSIZE * 0.5, py + PSIZE * 0.5).distance_to(part.pos) < 28.0:
					if not invincible and shield_timer <= 0.0:
						_die()
						return

	if px >= end_x:
		if boss_alive:
			# must beat boss first on hard
			px = end_x - 10.0
			_set_status("DEFEAT THE BOSS FIRST!")
		else:
			_complete()


func _process(delta: float) -> void:
	var dt: float = minf(delta, 0.05)
	title_pulse += dt
	name_cursor_blink += dt
	if status_timer > 0.0:
		status_timer -= dt
	if state == State.PLAYING:
		if countdown > 0.0:
			countdown -= dt
			holding = false
			jump_buffer = 0.0
			if countdown <= 0.0:
				countdown = 0.0
				freeze_input = false
				holding = false
				jump_buffer = 0.0
		else:
			acc += dt
			while acc >= STEP and state == State.PLAYING:
				acc -= STEP
				_sim(STEP)
	elif state == State.DEAD:
		dead_timer += dt
		if dead_timer >= 1.6:
			_restart()
	elif state == State.COMPLETE:
		complete_timer += dt
		if complete_timer > 2.8:
			_to_credits(true)
	elif state == State.CREDITS:
		credits_scroll += 42.0 * dt
	elif state == State.CUSTOMIZE and mic_recording:
		record_timer += dt
		if record_timer > 1.5:
			_stop_mic_record()
	elif state == State.MENU or state == State.NAME_ENTRY or state == State.CUSTOMIZE or state == State.CREDITS:
		menu_cam += 160.0 * dt

	if state == State.PLAYING or state == State.DEAD or state == State.COMPLETE:
		cam_x = px - PLAYER_SX

	if shake > 0.0:
		shake = maxf(0.0, shake - dt)
		shake_off = Vector2(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)) * shake * 24.0
	else:
		shake_off = Vector2.ZERO
	flash = maxf(0.0, flash - dt * 2.5)

	_update_particles(dt)
	queue_redraw()


# ============================================================================
# PARTICLES
# ============================================================================
func _spawn(pos: Vector2, vel: Vector2, life: float, col: Color, size: float) -> void:
	if particles.size() > 500:
		return
	var p := Particle.new()
	p.pos = pos
	p.vel = vel
	p.life = life
	p.max_life = life
	p.color = col
	p.size = size
	particles.append(p)


func _burst(pos: Vector2, n: int, col: Color, speed: float) -> void:
	for i in range(n):
		var ang: float = randf() * TAU
		var spd: float = randf_range(0.2, 1.0) * speed
		_spawn(pos, Vector2(cos(ang), sin(ang)) * spd, randf_range(0.35, 0.8), col, randf_range(3.0, 8.0))


func _update_particles(dt: float) -> void:
	var i: int = particles.size() - 1
	while i >= 0:
		var p: Particle = particles[i]
		p.life -= dt
		if p.life <= 0.0:
			particles.remove_at(i)
		else:
			p.vel.y += 900.0 * dt
			p.pos += p.vel * dt
		i -= 1


# ============================================================================
# DRAWING
# ============================================================================
func _make_bg() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 5
	bg_total = 0.0
	bg_bars.clear()
	for i in range(48):
		var b := Vector2(rng.randf_range(60.0, 140.0), rng.randf_range(80.0, 340.0))
		bg_bars.append(b)
		bg_total += b.x
	# stars (denser field)
	stars.clear()
	rng.seed = 42
	for i in range(220):
		stars.append(Vector2(rng.randf_range(0.0, 4000.0), rng.randf_range(10.0, GROUND_Y - 30.0)))


func _text(s: String, pos: Vector2, size: int, color: Color, align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT, width: float = -1.0) -> void:
	var f: Font = ThemeDB.fallback_font
	draw_string(f, pos + Vector2(2.0, 2.0), s, align, width, size, Color(0.0, 0.0, 0.0, 0.45 * color.a))
	draw_string(f, pos, s, align, width, size, color)


func _draw_rounded_rect(r: Rect2, color: Color, radius: float = 12.0, filled: bool = true) -> void:
	# Approximate rounded rect with rects + circles for polish
	if filled:
		draw_rect(Rect2(r.position.x + radius, r.position.y, r.size.x - radius * 2.0, r.size.y), color)
		draw_rect(Rect2(r.position.x, r.position.y + radius, r.size.x, r.size.y - radius * 2.0), color)
		draw_circle(r.position + Vector2(radius, radius), radius, color)
		draw_circle(Vector2(r.end.x - radius, r.position.y + radius), radius, color)
		draw_circle(Vector2(r.position.x + radius, r.end.y - radius), radius, color)
		draw_circle(r.end - Vector2(radius, radius), radius, color)
	else:
		draw_rect(r, color, false, 3.0)


func _draw() -> void:
	draw_set_transform(shake_off, 0.0, Vector2.ONE)
	if state == State.NAME_ENTRY:
		_draw_bg(menu_cam * 0.3, hue_base)
		_draw_name_entry()
	elif state == State.MENU:
		_draw_bg(menu_cam, hue_base)
		_draw_ground(menu_cam, hue_base, false)
		_draw_menu()
	elif state == State.CUSTOMIZE:
		_draw_bg(menu_cam * 0.4, hue_base)
		_draw_customize()
	elif state == State.CREDITS:
		_draw_bg(menu_cam * 0.25, hue_base)
		_draw_credits()
	else:
		var h: float = _hue_now()
		_draw_bg(cam_x, h)
		_draw_world(h)
		_draw_hud()
	if flash > 0.0:
		draw_rect(Rect2(-40.0, -40.0, W + 80.0, H + 80.0), Color(1.0, 1.0, 1.0, flash * 0.5))
	if status_timer > 0.0 and status_msg != "":
		var a: float = clampf(status_timer * 2.0, 0.0, 1.0)
		_text(status_msg, Vector2(0.0, H - 40.0), 26, Color(1.0, 1.0, 0.6, a), HORIZONTAL_ALIGNMENT_CENTER, W)


func _draw_bg(cam: float, h: float) -> void:
	var top: Color = Color.from_hsv(h, 0.65, 0.38)
	var bot: Color = Color.from_hsv(fposmod(h + 0.06, 1.0), 0.8, 0.10)
	var quad := PackedVector2Array([Vector2(-40.0, -40.0), Vector2(W + 40.0, -40.0), Vector2(W + 40.0, H + 40.0), Vector2(-40.0, H + 40.0)])
	draw_polygon(quad, PackedColorArray([top, top, bot, bot]))
	# soft nebula blobs
	for i in range(4):
		var nx: float = fposmod(float(i) * 310.0 - cam * 0.08, W + 200.0) - 100.0
		var ny: float = 80.0 + float(i % 3) * 70.0
		var nc := Color.from_hsv(fposmod(h + 0.1 * float(i), 1.0), 0.55, 0.5, 0.06)
		draw_circle(Vector2(nx, ny), 90.0 + float(i) * 20.0, nc)
	# distant planet
	var planet_x: float = fposmod(900.0 - cam * 0.05, W + 300.0) - 80.0
	if planet_x > -80.0 and planet_x < W + 80.0:
		var pc := Color.from_hsv(fposmod(h + 0.15, 1.0), 0.4, 0.55, 0.35)
		draw_circle(Vector2(planet_x, 120.0), 48.0, pc)
		draw_circle(Vector2(planet_x - 10.0, 110.0), 14.0, Color(pc.r, pc.g, pc.b, 0.2))
		# thin ring
		draw_arc(Vector2(planet_x, 120.0), 62.0, -0.4, PI + 0.4, 24, Color(1.0, 1.0, 1.0, 0.12), 2.0)
	# stars (denser)
	var star_off: float = fposmod(cam * 0.15, 4000.0)
	for s: Vector2 in stars:
		var sx: float = fposmod(s.x - star_off, 4000.0) - 200.0
		if sx > -20.0 and sx < W + 20.0:
			var twinkle: float = 0.5 + 0.5 * sin(title_pulse * 3.0 + s.x * 0.01)
			var sz: float = 1.0 + twinkle * 1.2
			draw_circle(Vector2(sx, s.y), sz, Color(1.0, 1.0, 1.0, 0.3 + twinkle * 0.5))
			if int(s.x) % 7 == 0:
				# occasional cross sparkle
				draw_line(Vector2(sx - 4.0, s.y), Vector2(sx + 4.0, s.y), Color(1.0, 1.0, 1.0, 0.2 * twinkle), 1.0)
				draw_line(Vector2(sx, s.y - 4.0), Vector2(sx, s.y + 4.0), Color(1.0, 1.0, 1.0, 0.2 * twinkle), 1.0)
	# subtle scanlines
	var sy: float = fmod(title_pulse * 30.0, 8.0)
	while sy < H:
		draw_line(Vector2(0.0, sy), Vector2(W, sy), Color(1.0, 1.0, 1.0, 0.015), 1.0)
		sy += 8.0
	# soft vertical grid
	var gx: float = -fposmod(cam * 0.4, 120.0)
	while gx < W + 120.0:
		draw_line(Vector2(gx, 0.0), Vector2(gx, H), Color(1.0, 1.0, 1.0, 0.03), 1.0)
		gx += 120.0
	# skyline layers
	for layer in range(3):
		var speed: float = 0.18 + 0.16 * float(layer)
		var shade: Color = Color.from_hsv(fposmod(h + 0.025 * float(layer), 1.0), 0.7, 0.16 + 0.09 * float(layer))
		shade.a = 0.45 + 0.14 * float(layer)
		var x: float = -fposmod(cam * speed + float(layer) * 280.0, bg_total)
		var i: int = layer * 9
		while x < W:
			var b: Vector2 = bg_bars[i % bg_bars.size()]
			if x + b.x > 0.0:
				var hh: float = b.y * (0.55 + 0.22 * float(layer))
				var rx := Rect2(x, GROUND_Y - hh, b.x - 8.0, hh)
				draw_rect(rx, shade)
				# antenna / detail on tall buildings
				if layer == 2 and b.y > 200.0 and (i % 4 == 0):
					draw_line(Vector2(x + b.x * 0.5, GROUND_Y - hh), Vector2(x + b.x * 0.5, GROUND_Y - hh - 18.0), Color(1.0, 1.0, 1.0, 0.15), 2.0)
					draw_circle(Vector2(x + b.x * 0.5, GROUND_Y - hh - 20.0), 2.5, Color(1.0, 0.4, 0.4, 0.5))
				# window lights
				if layer == 2 and b.x > 40.0:
					var wc := Color(1.0, 0.9, 0.55, 0.22)
					for wy in range(3):
						for wx in range(int((b.x - 16.0) / 18.0)):
							if (i + wx + wy) % 3 != 0:
								draw_rect(Rect2(x + 8.0 + float(wx) * 18.0, GROUND_Y - hh + 12.0 + float(wy) * 22.0, 7.0, 9.0), wc)
			x += b.x
			i += 1


func _ground_seg(a: float, b: float, fillc: Color, edge: Color) -> void:
	draw_rect(Rect2(a, GROUND_Y, b - a, H - GROUND_Y + 40.0), fillc)
	draw_line(Vector2(a, GROUND_Y), Vector2(b, GROUND_Y), edge, 4.0)


func _draw_ground(cam: float, h: float, use_pits: bool) -> void:
	var fillc: Color = Color.from_hsv(h, 0.7, 0.20)
	var edge: Color = Color.from_hsv(h, 0.30, 1.0)
	var x0: float = cam - 20.0
	var x1: float = cam + W + 20.0
	var cursor: float = x0
	if use_pits:
		for p: Vector2 in pits:
			if p.y < x0 or p.x > x1:
				continue
			if p.x > cursor:
				_ground_seg(cursor - cam, p.x - cam, fillc, edge)
			cursor = maxf(cursor, p.y)
	if x1 > cursor:
		_ground_seg(cursor - cam, x1 - cam, fillc, edge)


func _draw_spike_shape(r: Rect2, col: Color, upside_down: bool = false) -> void:
	var pts: PackedVector2Array
	if upside_down:
		pts = PackedVector2Array([
			Vector2(r.position.x, r.position.y),
			Vector2(r.end.x, r.position.y),
			Vector2(r.position.x + r.size.x * 0.5, r.end.y)
		])
	else:
		pts = PackedVector2Array([
			Vector2(r.position.x, r.end.y),
			Vector2(r.end.x, r.end.y),
			Vector2(r.position.x + r.size.x * 0.5, r.position.y)
		])
	draw_colored_polygon(pts, col)
	draw_polyline(PackedVector2Array([pts[0], pts[1], pts[2], pts[0]]), Color.WHITE, 2.0)


func _draw_world(h: float) -> void:
	var edge: Color = Color.from_hsv(h, 0.30, 1.0)
	var fillc: Color = Color.from_hsv(h, 0.65, 0.50)
	var inner: Color = fillc.darkened(0.30)
	_draw_ground(cam_x, h, true)

	# blocks
	for b: Rect2 in blocks:
		var rx := Rect2(b.position.x - cam_x, b.position.y, b.size.x, b.size.y)
		if rx.end.x < -20.0 or rx.position.x > W + 20.0:
			continue
		draw_rect(rx, fillc)
		draw_rect(rx.grow(-6.0), inner)
		draw_rect(rx, edge, false, 3.0)

	# floor spikes
	var spike_col := Color.from_hsv(fposmod(h + 0.05, 1.0), 0.8, 0.95)
	for s: Rect2 in spikes:
		var rx := Rect2(s.position.x - cam_x, s.position.y, s.size.x, s.size.y)
		if rx.end.x < -20.0 or rx.position.x > W + 20.0:
			continue
		_draw_spike_shape(rx, spike_col, false)

	# ceiling spikes
	var ceil_col := Color.from_hsv(fposmod(h + 0.12, 1.0), 0.85, 0.9)
	for s: Rect2 in ceiling_spikes:
		var rx := Rect2(s.position.x - cam_x, s.position.y, s.size.x, s.size.y)
		if rx.end.x < -20.0 or rx.position.x > W + 20.0:
			continue
		_draw_spike_shape(rx, ceil_col, true)

	# pads
	for p: Rect2 in pads:
		var rx := Rect2(p.position.x - cam_x, p.position.y, p.size.x, p.size.y)
		if rx.end.x < -20.0 or rx.position.x > W + 20.0:
			continue
		draw_rect(rx, Color(1.0, 0.85, 0.15))
		draw_rect(rx, Color.WHITE, false, 2.0)

	# portals
	for i in range(portal_x.size()):
		var xx: float = portal_x[i] - cam_x
		if xx < -80.0 or xx > W + 80.0:
			continue
		var pc: Color = Color(1.0, 0.3, 0.85) if portal_mode[i] == Mode.SHIP else Color(0.3, 1.0, 0.55)
		draw_rect(Rect2(xx - 20.0, 0.0, 40.0, GROUND_Y), Color(pc.r, pc.g, pc.b, 0.16))
		draw_line(Vector2(xx - 20.0, 0.0), Vector2(xx - 20.0, GROUND_Y), pc, 3.0)
		draw_line(Vector2(xx + 20.0, 0.0), Vector2(xx + 20.0, GROUND_Y), pc, 3.0)

	# finish line
	var fx: float = end_x - cam_x
	if fx > -80.0 and fx < W + 80.0:
		draw_rect(Rect2(fx, 0.0, 60.0, GROUND_Y), Color(1.0, 1.0, 1.0, 0.22))
		draw_line(Vector2(fx, 0.0), Vector2(fx, GROUND_Y), Color.WHITE, 4.0)
		_text("FINISH", Vector2(fx - 60.0, 320.0), 44, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 180.0)

	# checkpoints (flags)
	for i in range(checkpoints.size()):
		var cx: float = checkpoints[i] - cam_x
		if cx < -40.0 or cx > W + 40.0:
			continue
		var activated: bool = i <= checkpoint_idx
		var fc := Color(0.3, 1.0, 0.5) if activated else Color(0.7, 0.7, 0.75)
		draw_line(Vector2(cx, GROUND_Y), Vector2(cx, GROUND_Y - 70.0), fc, 4.0)
		var flag := PackedVector2Array([Vector2(cx, GROUND_Y - 70.0), Vector2(cx + 28.0, GROUND_Y - 58.0), Vector2(cx, GROUND_Y - 46.0)])
		draw_colored_polygon(flag, fc)

	# coins
	for i in range(coins.size()):
		if coin_got[i]:
			continue
		var cpos: Vector2 = coins[i]
		var sx: float = cpos.x - cam_x
		if sx < -30.0 or sx > W + 30.0:
			continue
		var bob: float = sin(title_pulse * 4.0 + cpos.x * 0.01) * 4.0
		var cy: float = cpos.y + bob
		draw_circle(Vector2(sx, cy), 12.0, Color(1.0, 0.82, 0.15))
		draw_circle(Vector2(sx, cy), 12.0, Color(1.0, 0.95, 0.4), false, 2.0)
		_text("$", Vector2(sx - 6.0, cy + 6.0), 16, Color(0.55, 0.35, 0.05))

	# power-ups
	for p in powerups:
		if p["taken"]:
			continue
		var ppos: Vector2 = p["pos"]
		var sx: float = ppos.x - cam_x
		if sx < -30.0 or sx > W + 30.0:
			continue
		var bob: float = sin(title_pulse * 3.0 + ppos.x * 0.02) * 5.0
		var col: Color
		var label: String
		match int(p["type"]):
			PowerType.SPEED:
				col = Color(1.0, 0.5, 0.15)
				label = "SPD"
			PowerType.SLOW:
				col = Color(0.4, 0.7, 1.0)
				label = "SLW"
			_:
				col = Color(0.5, 1.0, 0.7)
				label = "SHD"
		draw_circle(Vector2(sx, ppos.y + bob), 14.0, col)
		draw_circle(Vector2(sx, ppos.y + bob), 14.0, Color.WHITE, false, 2.0)
		_text(label, Vector2(sx - 14.0, ppos.y + bob + 6.0), 14, Color.WHITE)

	# boss
	if boss_alive and boss_x > 0.0:
		var bx: float = boss_x - cam_x
		if bx > -100.0 and bx < W + 100.0:
			var by: float = GROUND_Y - 90.0 + sin(boss_phase * 2.2) * 50.0
			# brainrot body
			draw_circle(Vector2(bx, by), 36.0, Color(1.0, 0.35, 0.55))
			draw_circle(Vector2(bx, by), 36.0, Color(1.0, 0.1, 0.3), false, 3.0)
			# eyes
			draw_circle(Vector2(bx - 12.0, by - 8.0), 8.0, Color.WHITE)
			draw_circle(Vector2(bx + 12.0, by - 8.0), 8.0, Color.WHITE)
			draw_circle(Vector2(bx - 12.0, by - 8.0), 4.0, Color.BLACK)
			draw_circle(Vector2(bx + 12.0, by - 8.0), 4.0, Color.BLACK)
			# angry brows
			draw_line(Vector2(bx - 20.0, by - 18.0), Vector2(bx - 4.0, by - 14.0), Color.BLACK, 3.0)
			draw_line(Vector2(bx + 20.0, by - 18.0), Vector2(bx + 4.0, by - 14.0), Color.BLACK, 3.0)
			_text("BRAINROT", Vector2(bx - 40.0, by - 48.0), 16, Color(1.0, 0.3, 0.4))
			# HP pips
			for h in range(3):
				var hc := Color(1.0, 0.2, 0.3) if h < int(boss_hp) else Color(0.2, 0.2, 0.25)
				draw_rect(Rect2(bx - 24.0 + h * 18.0, by + 44.0, 14.0, 8.0), hc)

	# particles
	for p: Particle in particles:
		var a: float = clampf(p.life / p.max_life, 0.0, 1.0)
		var sz: float = p.size * (0.4 + 0.6 * a)
		draw_rect(Rect2(p.pos.x - cam_x - sz * 0.5, p.pos.y - sz * 0.5, sz, sz), Color(p.color.r, p.color.g, p.color.b, a))

	if state != State.DEAD:
		_draw_player()


func _draw_player() -> void:
	var c := Vector2(px - cam_x + PSIZE * 0.5, py + PSIZE * 0.5)
	draw_set_transform(c + shake_off, rot, Vector2.ONE)
	var main_c: Color = Color(1.0, 0.85, 0.2)
	var dark: Color = Color(0.08, 0.08, 0.15)
	# shield aura
	if shield_timer > 0.0:
		draw_circle(Vector2.ZERO, PSIZE * 0.75, Color(0.4, 0.9, 1.0, 0.25))
		draw_circle(Vector2.ZERO, PSIZE * 0.75, Color(0.5, 1.0, 1.0, 0.6), false, 2.0)
	if mode == Mode.CUBE:
		var r := Rect2(-PSIZE * 0.5, -PSIZE * 0.5, PSIZE, PSIZE)
		if has_custom_icon and player_tex != null:
			draw_texture_rect(player_tex, r, false)
			draw_rect(r, Color.WHITE, false, 3.0)
		else:
			match icon_type:
				IconType.TRIANGLE:
					var tri := PackedVector2Array([Vector2(0.0, -20.0), Vector2(20.0, 18.0), Vector2(-20.0, 18.0)])
					draw_colored_polygon(tri, main_c)
					draw_polyline(PackedVector2Array([tri[0], tri[1], tri[2], tri[0]]), Color.WHITE, 3.0)
				IconType.CIRCLE:
					draw_circle(Vector2.ZERO, 20.0, main_c)
					draw_circle(Vector2.ZERO, 20.0, Color.WHITE, false, 3.0)
				IconType.DIAMOND:
					var dia := PackedVector2Array([Vector2(0.0, -20.0), Vector2(18.0, 0.0), Vector2(0.0, 20.0), Vector2(-18.0, 0.0)])
					draw_colored_polygon(dia, main_c)
					draw_polyline(PackedVector2Array([dia[0], dia[1], dia[2], dia[3], dia[0]]), Color.WHITE, 3.0)
				IconType.BALL:
					draw_circle(Vector2.ZERO, 20.0, Color(1.0, 0.55, 0.2))
					draw_circle(Vector2.ZERO, 20.0, Color.WHITE, false, 3.0)
					draw_circle(Vector2(-6.0, -4.0), 4.0, dark)
					draw_circle(Vector2(6.0, -4.0), 4.0, dark)
				IconType.UFO:
					draw_circle(Vector2(0.0, 2.0), 14.0, Color(0.6, 1.0, 0.7))
					draw_colored_polygon(PackedVector2Array([Vector2(-22.0, 6.0), Vector2(22.0, 6.0), Vector2(14.0, 14.0), Vector2(-14.0, 14.0)]), Color(0.4, 0.8, 1.0))
				_:
					draw_rect(r, main_c)
					draw_rect(r, Color.WHITE, false, 3.0)
					draw_rect(Rect2(-12.0, -8.0, 8.0, 10.0), dark)
					draw_rect(Rect2(4.0, -8.0, 8.0, 10.0), dark)
					draw_rect(Rect2(-12.0, 8.0, 24.0, 5.0), dark)
	else:
		var hull := PackedVector2Array([Vector2(-24.0, 12.0), Vector2(-24.0, 0.0), Vector2(0.0, -10.0), Vector2(26.0, 2.0), Vector2(26.0, 12.0)])
		draw_colored_polygon(hull, Color(1.0, 0.35, 0.8))
		draw_polyline(PackedVector2Array([hull[0], hull[1], hull[2], hull[3], hull[4], hull[0]]), Color.WHITE, 3.0)
		var cube := Rect2(-8.0, -22.0, 22.0, 20.0)
		if has_custom_icon and player_tex != null:
			draw_texture_rect(player_tex, cube, false)
			draw_rect(cube, Color.WHITE, false, 2.0)
		else:
			draw_rect(cube, main_c)
			draw_rect(cube, Color.WHITE, false, 2.0)
	draw_set_transform(shake_off, 0.0, Vector2.ONE)


func _draw_hud() -> void:
	var pct: float = _pct()
	# thin minimal progress
	var bar := Rect2(W * 0.5 - 280.0, 24.0, 560.0, 4.0)
	draw_rect(bar, Color(1.0, 1.0, 1.0, 0.12))
	draw_rect(Rect2(bar.position, Vector2(bar.size.x * pct / 100.0, bar.size.y)), Color(1.0, 1.0, 1.0, 0.85))
	_text(str(int(pct)) + "%", Vector2(bar.end.x + 12.0, 32.0), 20, Color(1.0, 1.0, 1.0, 0.8))
	_text("ATTEMPT " + str(attempt), Vector2(24.0, 32.0), 18, Color(1.0, 1.0, 1.0, 0.55))
	# coin counter
	draw_circle(Vector2(32.0, 62.0), 9.0, Color(1.0, 0.82, 0.15))
	_text("%d / %d" % [coins_collected, coins_total], Vector2(48.0, 68.0), 18, Color(1.0, 0.9, 0.4, 0.9))
	if checkpoint_idx >= 0:
		_text("CP %d" % (checkpoint_idx + 1), Vector2(24.0, 110.0), 18, Color(0.4, 1.0, 0.6))
	if speed_timer > 0.0:
		_text("SPEED", Vector2(W - 120.0, 50.0), 20, Color(1.0, 0.55, 0.2))
	if slow_timer > 0.0:
		_text("SLOW-MO", Vector2(W - 120.0, 74.0), 20, Color(0.5, 0.8, 1.0))
	if shield_timer > 0.0:
		_text("SHIELD", Vector2(W - 120.0, 98.0), 20, Color(0.5, 1.0, 0.75))
	if invincible:
		_text("INVINCIBLE", Vector2(24.0, 134.0), 20, Color(1.0, 0.4, 0.4))
	if countdown > 0.0 and state == State.PLAYING:
		var n: int = int(ceil(countdown))
		draw_rect(Rect2(0.0, 0.0, W, H), Color(0.0, 0.0, 0.0, 0.35))
		_text(str(n), Vector2(0.0, H * 0.5 + 30.0), 120, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, W)
		var label: String = "CHECKPOINT" if checkpoint_idx >= 0 else "GET READY"
		_text(label, Vector2(0.0, H * 0.5 + 70.0), 28, Color(1.0, 1.0, 1.0, 0.7), HORIZONTAL_ALIGNMENT_CENTER, W)
	if state == State.DEAD:
		# GTA-style WASTED
		draw_rect(Rect2(0.0, H * 0.5 - 48.0, W, 96.0), Color(0.25, 0.25, 0.25, 0.92))
		_text("wasted", Vector2(0.0, H * 0.5 + 18.0), 72, Color(1.0, 0.12, 0.12), HORIZONTAL_ALIGNMENT_CENTER, W)
		_text(death_msg, Vector2(0.0, H * 0.5 + 58.0), 24, Color(1.0, 1.0, 1.0, 0.9), HORIZONTAL_ALIGNMENT_CENTER, W)
	elif state == State.COMPLETE:
		var n: String = player_name if player_name != "" else "Player"
		_text(n.to_upper() + " WON!", Vector2(0.0, 250.0), 56, Color(0.5, 1.0, 0.7), HORIZONTAL_ALIGNMENT_CENTER, W)
		_text("LEVEL COMPLETE!", Vector2(0.0, 310.0), 40, Color(1.0, 1.0, 1.0, 0.9), HORIZONTAL_ALIGNMENT_CENTER, W)
		_text("Attempts: " + str(attempt) + "   Coins: %d/%d" % [coins_collected, coins_total], Vector2(0.0, 360.0), 26, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, W)
		if complete_timer > 0.9:
			_text("Credits rolling…", Vector2(0.0, 420.0), 26, Color(1.0, 1.0, 1.0, 0.75), HORIZONTAL_ALIGNMENT_CENTER, W)
			_text("SPACE to skip to credits", Vector2(0.0, 460.0), 22, Color(1.0, 1.0, 1.0, 0.55), HORIZONTAL_ALIGNMENT_CENTER, W)


func _draw_name_entry() -> void:
	# Sleek minimal name entry (per level select)
	_text("HAVEN DASH", Vector2(0.0, 140.0), 56, Color(1.0, 1.0, 1.0, 0.95), HORIZONTAL_ALIGNMENT_CENTER, W)
	if pending_level >= 0 and pending_level < LEVELS.size():
		_text(str(LEVELS[pending_level]["name"]), Vector2(0.0, 200.0), 28, Color(0.6, 0.9, 1.0, 0.85), HORIZONTAL_ALIGNMENT_CENTER, W)
	_text("Enter your name to play", Vector2(0.0, 250.0), 24, Color(1.0, 1.0, 1.0, 0.7), HORIZONTAL_ALIGNMENT_CENTER, W)
	# Input box
	var box := Rect2(W * 0.5 - 200.0, 310.0, 400.0, 56.0)
	draw_rect(box, Color(1.0, 1.0, 1.0, 0.06))
	draw_rect(box, Color(1.0, 1.0, 1.0, 0.35), false, 2.0)
	var display: String = name_input
	if fmod(name_cursor_blink, 1.0) < 0.5:
		display += "|"
	_text(display, Vector2(box.position.x + 16.0, box.position.y + 38.0), 28, Color.WHITE)
	_text("Type your name  ·  ENTER to start  ·  ESC back", Vector2(0.0, 400.0), 20, Color(1.0, 1.0, 1.0, 0.5), HORIZONTAL_ALIGNMENT_CENTER, W)
	_text("by Lokesh", Vector2(0.0, 680.0), 18, Color(1.0, 1.0, 1.0, 0.4), HORIZONTAL_ALIGNMENT_CENTER, W)


func _draw_menu() -> void:
	# Sleek minimal title card
	var pulse: float = 0.94 + 0.06 * sin(title_pulse * 2.2)
	_text("HAVEN DASH", Vector2(0.0, 100.0), int(88.0 * pulse), Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, W)
	draw_line(Vector2(W * 0.5 - 60.0, 118.0), Vector2(W * 0.5 + 60.0, 118.0), Color(1.0, 1.0, 1.0, 0.35), 1.5)
	_text("Jump the spikes. Ride the beat.", Vector2(0.0, 155.0), 22, Color(1.0, 1.0, 1.0, 0.65), HORIZONTAL_ALIGNMENT_CENTER, W)
	_text("by Lokesh", Vector2(0.0, 185.0), 18, Color(1.0, 1.0, 1.0, 0.4), HORIZONTAL_ALIGNMENT_CENTER, W)
	if player_name != "":
		_text("Playing as " + player_name, Vector2(0.0, 210.0), 18, Color(0.55, 0.85, 1.0, 0.75), HORIZONTAL_ALIGNMENT_CENTER, W)
	for i in range(LEVELS.size()):
		var cfg: Dictionary = LEVELS[i]
		var r: Rect2 = _card_rect(i)
		var sel: bool = i == level_idx
		# Minimal glass cards
		var bg_a: float = 0.22 if sel else 0.10
		draw_rect(r, Color(1.0, 1.0, 1.0, bg_a))
		var border: Color = Color(1.0, 1.0, 1.0, 0.85) if sel else Color(1.0, 1.0, 1.0, 0.18)
		draw_rect(r, border, false, 1.5 if sel else 1.0)
		if sel:
			# accent line on left
			draw_rect(Rect2(r.position.x, r.position.y, 3.0, r.size.y), Color.from_hsv(float(cfg["hue"]), 0.7, 0.95))
		_text(str(cfg["name"]), Vector2(r.position.x, r.position.y + 55.0), 32, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, r.size.x)
		_text(str(cfg["tag"]), Vector2(r.position.x, r.position.y + 90.0), 18, Color(1.0, 1.0, 1.0, 0.55), HORIZONTAL_ALIGNMENT_CENTER, r.size.x)
		var bar := Rect2(r.position.x + 36.0, r.position.y + 130.0, r.size.x - 72.0, 6.0)
		draw_rect(bar, Color(1.0, 1.0, 1.0, 0.12))
		draw_rect(Rect2(bar.position, Vector2(bar.size.x * float(best[i]) / 100.0, bar.size.y)), Color(1.0, 1.0, 1.0, 0.75))
		_text(str(best[i]) + "%", Vector2(r.position.x, r.position.y + 165.0), 22, Color(1.0, 1.0, 1.0, 0.8), HORIZONTAL_ALIGNMENT_CENTER, r.size.x)
		if best_coins[i] > 0:
			_text("$" + str(best_coins[i]), Vector2(r.position.x, r.position.y + 195.0), 18, Color(1.0, 0.85, 0.3, 0.8), HORIZONTAL_ALIGNMENT_CENTER, r.size.x)
	# Minimal text buttons
	var cb := _customize_btn_rect()
	var cr := _credits_btn_rect()
	draw_rect(cb, Color(1.0, 1.0, 1.0, 0.08))
	draw_rect(cb, Color(1.0, 1.0, 1.0, 0.35), false, 1.0)
	_text("CUSTOMIZE", Vector2(cb.position.x, cb.position.y + 32.0), 18, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, cb.size.x)
	draw_rect(cr, Color(1.0, 1.0, 1.0, 0.08))
	draw_rect(cr, Color(1.0, 1.0, 1.0, 0.35), false, 1.0)
	_text("CREDITS", Vector2(cr.position.x, cr.position.y + 32.0), 18, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, cr.size.x)
	_text("← → select     SPACE play", Vector2(0.0, 640.0), 18, Color(1.0, 1.0, 1.0, 0.45), HORIZONTAL_ALIGNMENT_CENTER, W)
	var inv: String = "ON" if invincible else "OFF"
	var mus: String = "OFF" if muted else "ON"
	_text("I invincible (" + inv + ")   M music (" + mus + ")   O icon", Vector2(0.0, 675.0), 16, Color(1.0, 1.0, 1.0, 0.4), HORIZONTAL_ALIGNMENT_CENTER, W)


func _draw_customize() -> void:
	_text("CUSTOMIZE", Vector2(0.0, 70.0), 56, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, W)
	# Tabs
	var face_r := Rect2(W * 0.5 - 220.0, 120.0, 200.0, 44.0)
	var sound_r := Rect2(W * 0.5 + 20.0, 120.0, 200.0, 44.0)
	var face_sel: bool = customize_tab == CustomizeTab.FACE
	_draw_rounded_rect(face_r, Color(0.25, 0.5, 0.9, 0.95 if face_sel else 0.4), 10.0)
	_draw_rounded_rect(sound_r, Color(0.25, 0.5, 0.9, 0.95 if not face_sel else 0.4), 10.0)
	_text("FACE / ICON", Vector2(face_r.position.x, face_r.position.y + 30.0), 22, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, face_r.size.x)
	_text("JUMP SOUND", Vector2(sound_r.position.x, sound_r.position.y + 30.0), 22, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, sound_r.size.x)

	if customize_tab == CustomizeTab.FACE:
		_text("Put your face on the jumping cube!", Vector2(0.0, 185.0), 26, Color(1.0, 1.0, 1.0, 0.9), HORIZONTAL_ALIGNMENT_CENTER, W)
		# Larger preview with face guide
		var prev := Rect2(W * 0.5 - 110.0, 215.0, 220.0, 220.0)
		draw_rect(prev.grow(6.0), Color(0.05, 0.05, 0.1))
		draw_rect(prev, Color(0.12, 0.12, 0.18))
		if camera_active and camera_tex != null:
			draw_texture_rect(camera_tex, prev, false)
			# Face guide square + soft vignette corners
			var guide := prev.grow(-28.0)
			draw_rect(guide, Color(0.3, 1.0, 0.55, 0.85), false, 3.0)
			# corner brackets
			var br: float = 18.0
			var gc := Color(0.4, 1.0, 0.6, 0.95)
			for corner in [guide.position, Vector2(guide.end.x, guide.position.y), Vector2(guide.position.x, guide.end.y), guide.end]:
				pass
			draw_line(guide.position, guide.position + Vector2(br, 0), gc, 3.0)
			draw_line(guide.position, guide.position + Vector2(0, br), gc, 3.0)
			draw_line(Vector2(guide.end.x, guide.position.y), Vector2(guide.end.x - br, guide.position.y), gc, 3.0)
			draw_line(Vector2(guide.end.x, guide.position.y), Vector2(guide.end.x, guide.position.y + br), gc, 3.0)
			draw_line(Vector2(guide.position.x, guide.end.y), Vector2(guide.position.x + br, guide.end.y), gc, 3.0)
			draw_line(Vector2(guide.position.x, guide.end.y), Vector2(guide.position.x, guide.end.y - br), gc, 3.0)
			draw_line(guide.end, guide.end - Vector2(br, 0), gc, 3.0)
			draw_line(guide.end, guide.end - Vector2(0, br), gc, 3.0)
			_text("Centre your face in the green box", Vector2(0.0, 450.0), 22, Color(0.5, 1.0, 0.65), HORIZONTAL_ALIGNMENT_CENTER, W)
			_text("SPACE or click the preview to SNAP", Vector2(0.0, 478.0), 20, Color(1.0, 1.0, 0.5), HORIZONTAL_ALIGNMENT_CENTER, W)
		elif has_custom_icon and player_tex != null:
			draw_texture_rect(player_tex, prev, false)
			draw_rect(prev, Color(0.4, 1.0, 0.6, 0.9), false, 3.0)
			_text("Your current face icon", Vector2(0.0, 450.0), 22, Color(0.6, 1.0, 0.7), HORIZONTAL_ALIGNMENT_CENTER, W)
			_text("Open Camera again to retake", Vector2(0.0, 478.0), 20, Color(1.0, 1.0, 1.0, 0.65), HORIZONTAL_ALIGNMENT_CENTER, W)
		else:
			# default face preview
			var inner := prev.grow(-24.0)
			draw_rect(inner, Color(1.0, 0.85, 0.2))
			draw_rect(Rect2(inner.position.x + 36.0, inner.position.y + 50.0, 28.0, 32.0), Color(0.08, 0.08, 0.15))
			draw_rect(Rect2(inner.position.x + 108.0, inner.position.y + 50.0, 28.0, 32.0), Color(0.08, 0.08, 0.15))
			draw_rect(Rect2(inner.position.x + 36.0, inner.position.y + 120.0, 100.0, 16.0), Color(0.08, 0.08, 0.15))
			_text("Default yellow cube", Vector2(0.0, 450.0), 22, Color(1.0, 1.0, 1.0, 0.7), HORIZONTAL_ALIGNMENT_CENTER, W)
		# Buttons
		var cam_r := Rect2(W * 0.5 - 300.0, 520.0, 190.0, 50.0)
		var file_r := Rect2(W * 0.5 - 90.0, 520.0, 180.0, 50.0)
		var clear_r := Rect2(W * 0.5 + 110.0, 520.0, 170.0, 50.0)
		var cam_label: String = "Close Camera" if camera_active else "Open Camera"
		var cam_col := Color(0.85, 0.35, 0.25, 0.95) if camera_active else Color(0.2, 0.72, 0.42, 0.95)
		_draw_rounded_rect(cam_r, cam_col, 12.0)
		_draw_rounded_rect(file_r, Color(0.28, 0.5, 0.88, 0.95), 12.0)
		_draw_rounded_rect(clear_r, Color(0.65, 0.28, 0.28, 0.9), 12.0)
		_text(cam_label, Vector2(cam_r.position.x, cam_r.position.y + 33.0), 20, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, cam_r.size.x)
		_text("Load Image", Vector2(file_r.position.x, file_r.position.y + 33.0), 20, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, file_r.size.x)
		_text("Clear Face", Vector2(clear_r.position.x, clear_r.position.y + 33.0), 20, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, clear_r.size.x)
	else:
		_text("Record your own jump PING sound", Vector2(0.0, 200.0), 26, Color(1.0, 1.0, 1.0, 0.9), HORIZONTAL_ALIGNMENT_CENTER, W)
		_text("Hold ~0.3–1.0 seconds of a short 'ping' or voice", Vector2(0.0, 240.0), 22, Color(1.0, 1.0, 1.0, 0.7), HORIZONTAL_ALIGNMENT_CENTER, W)
		var rec_status: String = "● RECORDING..." if mic_recording else ("Custom sound ready" if has_custom_jump else "Using default ping")
		var rec_col: Color = Color(1.0, 0.3, 0.3) if mic_recording else (Color(0.4, 1.0, 0.5) if has_custom_jump else Color(1.0, 1.0, 1.0, 0.7))
		_text(rec_status, Vector2(0.0, 320.0), 32, rec_col, HORIZONTAL_ALIGNMENT_CENTER, W)
		if mic_recording:
			var bar_w: float = 300.0 * clampf(record_timer / 1.5, 0.0, 1.0)
			draw_rect(Rect2(W * 0.5 - 150.0, 370.0, 300.0, 12.0), Color(0.2, 0.2, 0.25))
			draw_rect(Rect2(W * 0.5 - 150.0, 370.0, bar_w, 12.0), Color(1.0, 0.3, 0.3))
		var rec_r := Rect2(W * 0.5 - 200.0, 480.0, 180.0, 48.0)
		var clear_r := Rect2(W * 0.5 + 20.0, 480.0, 180.0, 48.0)
		var rec_label: String = "Stop" if mic_recording else "Record"
		_draw_rounded_rect(rec_r, Color(0.85, 0.25, 0.25, 0.95) if mic_recording else Color(0.2, 0.7, 0.4, 0.9), 10.0)
		_draw_rounded_rect(clear_r, Color(0.5, 0.3, 0.3, 0.9), 10.0)
		_text(rec_label, Vector2(rec_r.position.x, rec_r.position.y + 32.0), 22, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, rec_r.size.x)
		_text("Reset Default", Vector2(clear_r.position.x, clear_r.position.y + 32.0), 20, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, clear_r.size.x)
		_text("SPACE also starts / stops recording", Vector2(0.0, 560.0), 20, Color(1.0, 1.0, 1.0, 0.6), HORIZONTAL_ALIGNMENT_CENTER, W)

	_text("ESC: back to menu", Vector2(0.0, 680.0), 22, Color(1.0, 1.0, 1.0, 0.7), HORIZONTAL_ALIGNMENT_CENTER, W)


# ============================================================================
# CREDITS (cinematic roll)
# ============================================================================
func _credits_lines() -> Array:
	return [
		{"t": "HAVEN DASH", "s": 64, "gap": 28.0, "c": Color(1.0, 1.0, 1.0)},
		{"t": "", "s": 20, "gap": 36.0, "c": Color.WHITE},
		{"t": "A RHYTHM PLATFORMER", "s": 28, "gap": 48.0, "c": Color(0.75, 0.9, 1.0)},
		{"t": "", "s": 20, "gap": 40.0, "c": Color.WHITE},
		{"t": "CREATED BY", "s": 22, "gap": 18.0, "c": Color(1.0, 0.85, 0.4)},
		{"t": "Lokesh", "s": 48, "gap": 48.0, "c": Color.WHITE},
		{"t": "GAME DESIGN", "s": 22, "gap": 18.0, "c": Color(1.0, 0.85, 0.4)},
		{"t": "Lokesh", "s": 36, "gap": 40.0, "c": Color.WHITE},
		{"t": "CODING", "s": 22, "gap": 18.0, "c": Color(1.0, 0.85, 0.4)},
		{"t": "Lokesh", "s": 36, "gap": 40.0, "c": Color.WHITE},
		{"t": "SOUND EFFECTS", "s": 22, "gap": 18.0, "c": Color(1.0, 0.85, 0.4)},
		{"t": "Myinstants", "s": 34, "gap": 12.0, "c": Color.WHITE},
		{"t": "(myinstants.com)", "s": 20, "gap": 40.0, "c": Color(1.0, 1.0, 1.0, 0.65)},
		{"t": "MUSIC", "s": 22, "gap": 18.0, "c": Color(1.0, 0.85, 0.4)},
		{"t": "Procedurally generated", "s": 28, "gap": 40.0, "c": Color.WHITE},
		{"t": "ENGINE", "s": 22, "gap": 18.0, "c": Color(1.0, 0.85, 0.4)},
		{"t": "Godot 4", "s": 32, "gap": 48.0, "c": Color.WHITE},
		{"t": "", "s": 20, "gap": 20.0, "c": Color.WHITE},
		{"t": "SPECIAL THANKS", "s": 22, "gap": 18.0, "c": Color(1.0, 0.85, 0.4)},
		{"t": "Everyone who jumps the spikes", "s": 26, "gap": 48.0, "c": Color.WHITE},
		{"t": "", "s": 20, "gap": 30.0, "c": Color.WHITE},
		{"t": "THANKS FOR PLAYING", "s": 40, "gap": 28.0, "c": Color(0.5, 1.0, 0.7)},
		{"t": "HAVEN DASH", "s": 52, "gap": 20.0, "c": Color.WHITE},
	]


func _draw_credits() -> void:
	# Cinematic letterbox bars
	draw_rect(Rect2(0.0, 0.0, W, 70.0), Color(0.0, 0.0, 0.0, 0.85))
	draw_rect(Rect2(0.0, H - 70.0, W, 70.0), Color(0.0, 0.0, 0.0, 0.85))
	draw_rect(Rect2(0.0, 70.0, 80.0, H - 140.0), Color(0.0, 0.0, 0.0, 0.25))
	draw_rect(Rect2(W - 80.0, 70.0, 80.0, H - 140.0), Color(0.0, 0.0, 0.0, 0.25))

	var lines: Array = _credits_lines()
	var y: float = H + 40.0 - credits_scroll
	for line in lines:
		var s: int = int(line["s"])
		var gap: float = float(line["gap"])
		var col: Color = line["c"]
		var t: String = str(line["t"])
		if t != "":
			if y > -80.0 and y < H + 40.0:
				var a: float = 1.0
				if y < 120.0:
					a = clampf((y - 70.0) / 50.0, 0.0, 1.0)
				if y > H - 120.0:
					a = clampf((H - 70.0 - y) / 50.0, 0.0, 1.0)
				col.a = a
				_text(t, Vector2(0.0, y), s, col, HORIZONTAL_ALIGNMENT_CENTER, W)
		y += gap

	var hint: String = "SPACE / click — continue" if credits_from_complete else "ESC or SPACE — back to menu"
	_text(hint, Vector2(0.0, H - 38.0), 20, Color(1.0, 1.0, 1.0, 0.7), HORIZONTAL_ALIGNMENT_CENTER, W)
	if credits_from_complete:
		_text("LEVEL CLEAR", Vector2(0.0, 42.0), 22, Color(0.5, 1.0, 0.7, 0.9), HORIZONTAL_ALIGNMENT_CENTER, W)


# ============================================================================
# AUDIO (all generated in code)
# ============================================================================
func _setup_audio() -> void:
	music_player = AudioStreamPlayer.new()
	music_player.volume_db = -9.0
	add_child(music_player)
	for i in range(4):
		var p := AudioStreamPlayer.new()
		p.volume_db = -8.0
		add_child(p)
		sfx_players.append(p)
	if not has_custom_jump:
		sfx_jump = _wav(_tone(0.12, 420.0, 880.0, 0.25, 1), false, RATE)
	sfx_pad = _wav(_tone(0.2, 300.0, 1200.0, 0.35, 0), false, RATE)
	sfx_portal = _wav(_tone(0.3, 200.0, 800.0, 0.3, 1), false, RATE)
	sfx_death = _wav(_mix(_tone(0.45, 300.0, 40.0, 0.6, 0), _tone(0.45, 0.0, 0.0, 0.45, 2)), false, RATE)
	var win := PackedFloat32Array()
	for f: float in [523.25, 659.25, 783.99, 1046.5]:
		win.append_array(_tone(0.14, f, f, 0.3, 1))
	sfx_win = _wav(win, false, RATE)


func _tone(dur: float, f0: float, f1: float, vol: float, wave: int = 0) -> PackedFloat32Array:
	var n: int = int(RATE * dur)
	var out := PackedFloat32Array()
	out.resize(n)
	var ph: float = 0.0
	for i in range(n):
		var k: float = float(i) / float(n)
		var f: float = lerpf(f0, f1, k)
		ph += f / RATE
		var v: float = 0.0
		if wave == 0:
			v = sin(TAU * ph)
		elif wave == 1:
			v = 1.0 if fposmod(ph, 1.0) < 0.5 else -1.0
		else:
			v = randf_range(-1.0, 1.0)
		out[i] = v * vol * (1.0 - k) * (1.0 - k * 0.3)
	return out


func _mix(a: PackedFloat32Array, b: PackedFloat32Array) -> PackedFloat32Array:
	var n: int = maxi(a.size(), b.size())
	var out := PackedFloat32Array()
	out.resize(n)
	for i in range(n):
		var va: float = a[i] if i < a.size() else 0.0
		var vb: float = b[i] if i < b.size() else 0.0
		out[i] = clampf(va + vb, -1.0, 1.0)
	return out


func _wav(samples: PackedFloat32Array, loop: bool = false, rate: float = RATE) -> AudioStreamWAV:
	var bytes := PackedByteArray()
	bytes.resize(samples.size() * 2)
	for i in range(samples.size()):
		var v: int = int(clampf(samples[i], -1.0, 1.0) * 32767.0)
		bytes[i * 2] = v & 0xFF
		bytes[i * 2 + 1] = (v >> 8) & 0xFF
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = int(rate)
	w.stereo = false
	w.data = bytes
	if loop:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = samples.size()
	return w


func _make_music(bpm: float, root: float) -> AudioStreamWAV:
	var rate: float = 16000.0
	var beat: float = 60.0 / bpm
	var eighth: float = beat * 0.5
	var total: int = int(rate * beat * 16.0)
	var out := PackedFloat32Array()
	out.resize(total)
	var chord_semi: Array[float] = [0.0, -4.0, 3.0, -2.0]
	var third: Array[float] = [3.0, 4.0, 4.0, 4.0]
	var bass_f: Array[float] = []
	var arp_f: Array = []
	for c in range(4):
		bass_f.append(root * pow(2.0, chord_semi[c] / 12.0))
		var offs: Array[float] = [0.0, third[c], 7.0, third[c]]
		var notes: Array[float] = []
		for k in range(4):
			notes.append(root * 4.0 * pow(2.0, (chord_semi[c] + offs[k]) / 12.0))
		arp_f.append(notes)
	for i in range(total):
		var t: float = float(i) / rate
		var bi: int = int(t / beat)
		var bt: float = t - float(bi) * beat
		var chord: int = (bi >> 2) & 3
		var v: float = 0.0
		# bass
		var bf: float = bass_f[chord]
		var be: float = exp(-bt * 3.5) * minf(1.0, bt * 150.0)
		v += (sin(TAU * bf * t) * 0.55 + sin(TAU * bf * 2.0 * t) * 0.12) * be
		# kick
		v += sin(TAU * (45.0 * bt + 5.0 * (1.0 - exp(-30.0 * bt)))) * exp(-bt * 12.0) * 0.8
		# snare on beats 2 and 4
		var bar_beat: int = bi & 3
		if bar_beat == 1 or bar_beat == 3:
			v += (randf_range(-1.0, 1.0) * 0.5 + sin(TAU * 190.0 * bt) * 0.3) * exp(-bt * 16.0) * 0.5
		# hat + arpeggio on eighth notes
		var et: float = fposmod(t, eighth)
		v += randf_range(-1.0, 1.0) * exp(-et * 70.0) * 0.10
		var ei: int = int(t / eighth)
		var chord_notes: Array = arp_f[chord]
		var af: float = chord_notes[ei & 3]
		var sq: float = 1.0 if fposmod(af * t, 1.0) < 0.25 else -1.0
		v += sq * exp(-et * 8.0) * minf(1.0, et * 250.0) * 0.10
		out[i] = clampf(v * 0.6, -1.0, 1.0)
	return _wav(out, true, rate)


func _play_music() -> void:
	if not music_cache.has(level_idx):
		var cfg: Dictionary = LEVELS[level_idx]
		music_cache[level_idx] = _make_music(float(cfg["bpm"]), float(cfg["root"]))
	music_player.stream = music_cache[level_idx]
	music_player.volume_db = -80.0 if muted else -9.0
	music_player.play()


func _play_sfx(stream: AudioStream) -> void:
	if muted or stream == null:
		return
	var p: AudioStreamPlayer = sfx_players[sfx_idx]
	sfx_idx = (sfx_idx + 1) % sfx_players.size()
	p.stream = stream
	p.play()
