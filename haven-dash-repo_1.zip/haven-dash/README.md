# HAVEN Dash

A rhythm platformer built in Godot 4. Jump spikes, ride pads, switch between cube and ship sections, and make it to the end of each level.

Everything is generated in code: the graphics, levels, music and sound effects. There are no external art or audio assets in the project.

> Play it on itch.io: https://lokesh-krish.itch.io/haven-dash

## Features

- 3 levels: Neon Start (Easy), Pulse Drive (Normal) and Haven Rush (Hard)
- Checkpoints about every 22% of a level
- Collectible coins and three power-ups: Speed Boost, Slow-Mo and Shield
- Boss fight on Hard (3 HP, defeated by stomping or with a shield)
- Six unlockable icons: Cube, Triangle, Circle, Diamond, Ball and UFO
- Custom face icon from a webcam photo or a loaded image
- Custom jump sound recorded with a microphone
- Name entry on first launch, used in win and death messages
- Scrolling credits after finishing a level

## Controls

| Key | Action |
| --- | --- |
| Space / Up / W / click / tap | Jump (hold to keep jumping) and fly the ship |
| A / D or arrow keys | Choose a level, or switch Customize tabs |
| C | Open Customize |
| O | Cycle through unlocked icons |
| M | Mute music |
| I | Toggle invincibility (progress is not saved while on) |
| Esc | Back to menu / close Customize |

## Run it

1. Install [Godot](https://godotengine.org/download) 4.3 or newer.
2. In the Project Manager, choose **Import** and select `project.godot`.
3. Press **F5** to play.

## Camera and microphone

Both are optional and only used in the Customize menu.

- The camera uses Godot's `CameraServer`. It works on Linux, macOS, Android and iOS, and Windows support is newer. It is not available in web exports.
- If no camera is available, **Load Image** still works.
- The microphone needs `audio/driver/enable_input=true`, which is already set in `project.godot`.
- Custom icons and sounds are saved to `user://player_icon.png` and `user://custom_jump.wav`.

## Project structure

```
haven-dash/
├── main.gd         # Game logic, rendering, audio synthesis, customization
├── main.tscn       # Scene that attaches the script
├── project.godot   # Window size, renderer, audio input
└── icon.svg        # Project icon
```

## Exporting

Open **Project → Export**, add a preset for your platform (Windows, Linux, macOS or Web), and export. The project uses the Compatibility renderer, so it also works as a web export.

## Credits

- Game design and direction: Lokesh
- Code written with AI assistance (Claude by Anthropic)
- Sound effects: Myinstants (myinstants.com)
- Music: procedurally generated in-engine
- Engine: [Godot](https://godotengine.org)

## License

The code is released under the MIT License (see `LICENSE`). Sound effects from third-party sources remain under their original terms.
